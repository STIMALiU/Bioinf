## This file accompanies the course 732A51 Bioinformatics 

## This software comes AS IS in the hope that it will be useful WITHOUT ANY WARRANTY, 
## NOT even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
## Please understand that there may still be bugs and errors. Use it at your own risk. 
## We take no responsibility for any errors or omissions in this code or for any misfortune 
## that may befall you or others as a result of its use. Please send comments and report 
## bugs to Krzysztof Bartoszek at krzbar@protonmail.ch .


# 1. Load tree
tr <- read.tree("sylvia_nj_k80.tre")

# 2. Remove species
tr <- drop.tip(tr, "Chamaea_fasciata")
tr <- drop.tip(tr, "Devioeca_papuana")

# 3. Unify names
tr$tip.label <- gsub("Curruca_", "Sylvia_", tr$tip.label)

# 4. Fix spelling errors
tr$tip.label[tr$tip.label == "Sylvia_ruppeli"] <- "Sylvia_rueppelli"

# 5. Extract matched ecological data
DF <- sylvia.eco[tr$tip.label, ]
